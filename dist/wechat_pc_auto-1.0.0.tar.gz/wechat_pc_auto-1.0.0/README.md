# wechat-pc-auto

[![PyPI version](https://badge.fury.io/py/wechat-pc-auto.svg)](https://badge.fury.io/py/wechat-pc-auto)
[![Python versions](https://img.shields.io/pypi/pyversions/wechat-pc-auto.svg)](https://pypi.org/project/wechat-pc-auto/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Stars](https://img.shields.io/github/stars/yourname/wechat-pc-auto?style=social)](https://github.com/yourname/wechat-pc-auto)

一个**稳定、纯 UI 自动化**的微信 PC 版消息与文件发送工具，基于 `uiautomation` 实现，无需截图识别。

支持发送文本、多文件，智能打开聊天，适配最新微信版本。

适用于：监控告警、定时汇报、日志推送、文件自动传输等场景。

## 安装

```bash
pip install wechat-pc-auto
```
## 快速开始

```python
from wechat_auto import WxAuto

wx = WxAuto()
wx.load_wechat()  # 自动激活微信

# 发送消息 + 文件到文件传输助手
wx.send_msg("自动化测试成功！\n多行消息正常显示", who="文件传输助手")
wx.send_files([
    "C:/report.pdf",
    "C:/screenshot.jpg"
], who="文件传输助手")
```
查看完整示例：examples/demo_send_to_file_helper.py

## 注意事项

- 仅支持 Windows 系统 + 微信 PC 版
- 请确保微信已登录且未被最小化
- 首次运行可能需要管理员权限（uiautomation 需要）
- 不支持发送表情包（可发送文本中的emoji）

## 项目特点

- 无需截图识别，完全基于 UI 自动化
- 适配不同微信版本窗口类名
- 智能选择最快方式进入聊天
- 真正的文件剪贴板复制（非路径文本）
- 模块化设计，易于扩展（如后续可加接收消息、自动回复等）

## 项目结构

```
wechat_auto/
├── core.py         # 主入口
├── window.py       # 窗口管理
├── chat.py         # 智能打开聊天
├── sender.py       # 发送消息和文件
├── clipboard.py    # 系统级文件复制
└── logger.py       # 日志
```

## 开源协议

MIT License - 随意使用、修改、商用均可

## 致谢

感谢 uiautomation 作者 yinkaisheng，以及所有在调试过程中提供反馈的用户。

Star 支持一下吧，让更多人用上稳定的微信自动化工具


