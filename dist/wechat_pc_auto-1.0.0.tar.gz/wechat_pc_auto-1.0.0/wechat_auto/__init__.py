# wechat_auto/__init__.py
from .core import WxAuto

__version__ = "1.0.0"
__author__ = "wangwei"
__all__ = ["WxAuto"]
